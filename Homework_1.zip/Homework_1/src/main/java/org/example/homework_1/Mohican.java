package org.example.homework_1;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
public class Mohican implements HairStyle{
    @Override
    public void display() {
        System.out.println("Mohican");
    }
}
