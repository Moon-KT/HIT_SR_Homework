package org.example.homework_1;

import org.springframework.stereotype.Component;

@Component("Vest")
public class Vest implements Outfit {
    @Override
    public void display() {
        System.out.println("Vest");
    }
}
