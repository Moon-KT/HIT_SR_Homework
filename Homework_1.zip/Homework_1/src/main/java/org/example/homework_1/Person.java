package org.example.homework_1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Person {

    private HairStyle hairStyle;

    private List<Outfit> outfit;

    @Autowired
    public Person(@Qualifier("Undercut") HairStyle hairStyle, List<Outfit> outfit) {
        this.hairStyle = hairStyle;
        this.outfit = outfit;
    }

    public HairStyle getHairStyle() {
        return hairStyle;
    }

    public void setHairStyle(HairStyle hairStyle) {
        this.hairStyle = hairStyle;
    }

    public List<Outfit> getOutfit() {
        return outfit;
    }

    public void setOutfit(List<Outfit> outfit) {
        this.outfit = outfit;
    }
}
