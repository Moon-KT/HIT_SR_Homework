package org.example.homework_1;

import org.springframework.stereotype.Component;

@Component
public interface HairStyle {
    void display();
}
