package org.example.homework_1;

import org.springframework.stereotype.Component;

@Component("Undercut")
public class Undercut implements HairStyle{
    @Override
    public void display() {
        System.out.println("Undercut");
    }
}
