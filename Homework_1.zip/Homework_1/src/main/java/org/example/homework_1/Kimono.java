package org.example.homework_1;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
//@Primary
public class Kimono implements Outfit{
    @Override
    public void display() {
        System.out.println("Kimono");
    }
}
